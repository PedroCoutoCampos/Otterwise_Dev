let km = 240
let vel = 80
let gasol = 20

let consumo = km / gasol
let horas = km / vel

console.log(`Média de consumo é de ${consumo} km/l`);
console.log(`Tempo de viagem foi de ${horas} horas`);
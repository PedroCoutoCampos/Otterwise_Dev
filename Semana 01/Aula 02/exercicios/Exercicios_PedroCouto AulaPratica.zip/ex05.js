let valor1 = 10
let valor2 = 5
let resultado = valor1 + valor2
console.log(`Valor armazenado foi ${resultado}`);

let valor1 = 3
let valor2 = 12
console.log(`Valor 1 = ${valor1}
Valor 2 = ${valor2}`);
console.log(`Valor 1 = ${valor2}
Valor 2 = ${valor1}`);
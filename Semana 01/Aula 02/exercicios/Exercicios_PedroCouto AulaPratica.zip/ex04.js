let x = 42
let y = -3.14
let a = x * y
console.log(a);
let numero = 35;
let numero2 = 7;


if (numero % numero2 === 0) {
    console.log("São multiplos");
} else {
    console.log("Não são multiplos");
}
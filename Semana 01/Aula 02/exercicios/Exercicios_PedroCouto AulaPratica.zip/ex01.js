let nome = "Pedro Couto"
let formacao = "Analise e Desenvolvimento de Sistemas"
console.log(`Meu nome é ${nome} e sou formado em ${formacao}`);
let valueOne = 2;
let valueTwo = 1;
let valueThree = 3;

console.log(`1º Número: ${valueOne}
2º Número: ${valueTwo} 
3º Número: ${valueThree}`);


console.log(`Trocando valores:
1º Número: ${valueTwo}
2º Número: ${valueThree} 
3º Número: ${valueOne}`);   
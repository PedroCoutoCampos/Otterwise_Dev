function double(x) {
    console.log(x + x);
}
double(-5)
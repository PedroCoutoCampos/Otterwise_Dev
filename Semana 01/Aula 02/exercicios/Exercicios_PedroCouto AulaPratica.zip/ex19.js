function checkSignal (x){
    if (x > 0) {
        console.log(`${x} é positivo.`);
    } else {
        console.log(`${x} é negativo.`);
    }
}

checkSignal(-5);
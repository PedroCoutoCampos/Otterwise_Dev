const um = "Otter"
const dois = "wise"
const tres = um + dois;
console.log(tres);
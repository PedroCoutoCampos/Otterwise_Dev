let salarioFixo = 2000
let valorTotalVendas = 30000
let porcentoComissao = 1
let comissao = valorTotalVendas * porcentoComissao / 100
let salario = comissao + salarioFixo


console.log(`Você vai receber R$ ${salario} esse mês`);
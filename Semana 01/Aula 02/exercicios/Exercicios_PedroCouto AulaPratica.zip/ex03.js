let nome = "Pedro Couto"
let sobrenome = " Campos"
console.log(nome + sobrenome);
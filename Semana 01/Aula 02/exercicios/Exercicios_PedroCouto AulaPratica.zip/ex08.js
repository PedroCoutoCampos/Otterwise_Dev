let nome = "Juliana"
let idade = 13

if (idade > 18) {
    console.log(`${nome}, você é maior de idade`);
} else (
    console.log(`${nome}, você é menor de idade`));



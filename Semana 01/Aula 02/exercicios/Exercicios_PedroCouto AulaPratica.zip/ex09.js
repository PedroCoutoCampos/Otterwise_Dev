let n1 = 7
let n2 = 7
if (n1 > n2) {
    console.log(`${n1} é maior que ${n2}`);
} else if (n1 < n2) {
    console.log(`${n2} é maior que ${n1}`);
} else if (n1 === n2) {
    console.log(`${n1} é iguail a ${n2}`);
}
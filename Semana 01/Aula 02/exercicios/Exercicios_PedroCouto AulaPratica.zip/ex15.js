let num = [10,5,20];


// para ficar na ordem certa
num.sort((a,b) => a - b);


console.log(num);


let num = 0
for (let index = 0; index <= 25; index++) {
    
    console.log(index);
}
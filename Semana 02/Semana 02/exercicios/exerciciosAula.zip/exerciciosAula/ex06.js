const num = [1, -7, -23, 25, -19, 13, 10, -8, 52, -153, -127];

for (let i = 0; i < num.length; i++) {
  if (num[i] > 0) {
    console.log(`Positivos = ${num[i]}`);
  }
}

const num = [-5,0,-3,-4,12];

for (let i = 0; i < num.length; i++) {
  if (num[i] >= 0) {
      let 
      console.log(num[i]);
      } 
} 
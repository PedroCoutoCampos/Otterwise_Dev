const nome = ["Angela", " Rosa", " Ticiana", " Carla", " Renata"];

console.log(`${nome}`);


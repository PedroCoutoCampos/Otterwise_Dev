let num = 0
for (let index = 10; index <= 200; index+=10) {
    console.log(index);
}
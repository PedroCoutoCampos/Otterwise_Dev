const myUser = {nome: "Juca", age: 25, email: "juca@gmail.com"};

console.log(myUser);
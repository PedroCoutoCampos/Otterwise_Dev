// Imprima no console 15 vezes a frase ‘Formação Otterwise’.

for (let index = 0; index < 15; index++) {
  console.log("Formação Otterwise");
}

for (let index = 0; index < 5; index++) {
  console.log("olá mundo");
  console.log(index);
}

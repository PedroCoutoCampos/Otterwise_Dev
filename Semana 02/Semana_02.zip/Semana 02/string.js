const firstName = "joao";
const lastName = "bretanha";
const age = 27;

console.log(firstName + " " + lastName + age);

console.log(`${firstName} ${lastName}`);

function hello() {
  return "hello";
}

console.log(`${hello()} joao`);

const frase = "Olá, meu nome é joao";

console.log(frase.split(" "));

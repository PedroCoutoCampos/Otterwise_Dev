const fruits = ["laranja", "banana", "maçã"];

// console.log(fruits[0]);
// console.log(fruits[1]);
// console.log(fruits[2]);

console.log(fruits.length);

for (let index = 0; index < fruits.length; index++) {
  const element = fruits[index];
  console.log(element);
}

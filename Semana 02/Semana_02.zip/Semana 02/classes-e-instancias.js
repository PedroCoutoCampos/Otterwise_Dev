let num = "1";
let name = "joao";

console.log(typeof num);
console.log(typeof name);

console.log(Number.parseInt(num));
console.log(+num);
console.log(Number.parseInt(name));

const date = new Date();

console.log(date);

console.log(Array.isArray([]));

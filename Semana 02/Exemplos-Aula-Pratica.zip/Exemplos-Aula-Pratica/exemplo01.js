//Valores de Entrada

let valueOne = 1000;
let valueTwo = 8;
let temp;

//___________________________________________________________________________________

console.log(valueOne);
console.log(valueTwo);

temp = valueOne;
valueOne = valueTwo;
valueTwo = temp;

console.log(valueOne);
console.log(valueTwo);

let cont = 0;

cont = cont + 2; // 2
cont = cont + 2; // 4
cont = cont + 2; // 6
cont = cont + 2; // 8

for (i = 0; i < 100; i = i + 1) console.log(cont);
